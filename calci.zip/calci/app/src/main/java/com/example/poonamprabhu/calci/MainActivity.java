package com.example.poonamprabhu.calci;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText ed1,ed2;
    Button button1, button2, button3, button4;
    TextView tt1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.neww);

        ed1=findViewById(R.id.e1);
        ed2=findViewById(R.id.e2);

        button1=findViewById(R.id.b1);
        button2=findViewById(R.id.b2);
        button3=findViewById(R.id.b3);
        button4=findViewById(R.id.b4);

        tt1=findViewById(R.id.t1);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=ed1.getText().toString();
                String b=ed2.getText().toString();

                int aa=Integer.parseInt(a);
                int bb=Integer.parseInt(b);
                int c=aa+bb;

                String answer=Integer.toString(c);
                tt1.setText(answer);
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=ed1.getText().toString();
                String b=ed2.getText().toString();

                int aa=Integer.parseInt(a);
                int bb=Integer.parseInt(b);
                int c=aa-bb;

                String answer=Integer.toString(c);
                tt1.setText(answer);
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=ed1.getText().toString();
                String b=ed2.getText().toString();

                int aa=Integer.parseInt(a);
                int bb=Integer.parseInt(b);
                int c=aa*bb;

                String answer=Integer.toString(c);
                tt1.setText(answer);
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=ed1.getText().toString();
                String b=ed2.getText().toString();

                int aa=Integer.parseInt(a);
                int bb=Integer.parseInt(b);
                int c=aa/bb;

                String answer=Integer.toString(c);
                tt1.setText(answer);
            }
        });


    }
}
